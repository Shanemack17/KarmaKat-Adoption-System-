#BIS425 spring '25
import sqlite3

#Only run this once to avoid duplicates


#create a connection
con=sqlite3.connect("KarmaKat.db")


#Check which tables exist
cursor = con.execute("SELECT name FROM sqlite_master WHERE type='table';")

tables = cursor.fetchall()
print("Tables in database:", tables)

#Create Cat Table
con.execute('''
CREATE TABLE IF NOT EXISTS Cat(
    CatID INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    age Integer,
    breed Text,
    gender TEXT,
    trait TEXT);''')


#con.execute('''INSERT INTO Cat(name, age, breed, gender, trait) VALUES(?,?,?,?,?)''', ('Tom', 1 ,'Tabby','Male','White paws'))

#con.execute('''INSERT INTO Cat(name, age, breed, gender, trait) VALUES(?,?,?,?,?)''', ('Jerry', 2 ,'Calico ','Male','Grey paws'))

#con.execute('''INSERT INTO Cat(name, age, breed, gender, trait) VALUES(?,?,?,?,?)''', ('Sam', 7 ,'Tabby','Male','Bobbed tail'))

#con.execute('''INSERT INTO Cat(name, age, breed, gender, trait) VALUES(?,?,?,?,?)''', ('Merry', 1 ,'Scottish Fold','Female','None'))

#con.execute('''INSERT INTO Cat(name, age, breed, gender, trait) VALUES(?,?,?,?,?)''', ('Krissy', 5 ,'Mainecoon','Female','Declawed'))

#Create Vet Table
con.execute('''CREATE TABLE IF NOT EXISTS Vet(
    Vet_ID INTEGER PRIMARY KEY,
    clinic TEXT,
    Foreign key (Vet_ID) references Staff(emp_id));''')

#Insert Vet Records
#con.execute('''INSERT INTO Vet(Vet_ID, clinic) Values(?,?)''', (1, 'KarmaKat'))

#con.execute('''INSERT INTO Vet(Vet_ID, clinic) Values(?,?)''', (2, 'KarmaKat'))

#con.execute('''INSERT INTO Vet(Vet_ID, clinic) Values(?,?)''', (3, 'KarmaKat'))

#con.execute('''INSERT INTO Vet(Vet_ID, clinic) Values(?,?)''', (4, 'KarmaKat'))

#con.execute('''INSERT INTO Vet(Vet_ID, clinic) Values(?,?)''', (5, 'KarmaKat'))

#Create Procedure Table
con.execute('''
CREATE TABLE IF NOT EXISTS Procedure(
    VisitID INTEGER Primary Key Autoincrement,
    Fixed TEXT,
    Flea TEXT,
    Dewormed TEXT,
    Microchip TEXT,
    EarCleaning TEXT,
    EarMite TEXT,
    NailTrim TEXT,
    FIVTest TEXT,
    FIVResult TEXT,
    EarTip TEXT,
    Notes TEXT,
    VetID INTEGER,
    CatID INTEGER,
    Foreign key (VetID) References Vet(Vet_ID),
    Foreign key (CatID) References Cat(CatID)
);''')

#Insert Procedure Records
#con.execute('''INSERT INTO Procedure (Fixed, Flea, Dewormed, Microchip, EarCleaning, EarMite, NailTrim, FIVTest, FIVResult, EarTip, Notes, VetID, CatID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);''' ('Yes', 'Yes', 'Yes', 'Yes', 'Yes','Yes','Yes','Yes', 'Negative', 'Yes', 'None', 2, 2))

#con.execute('''INSERT INTO Procedure (Fixed, Flea, Dewormed, Microchip, EarCleaning, EarMite, NailTrim, FIVTest, FIVResult, EarTip, Notes, VetID, CatID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);''' ('Yes', 'Yes', 'Yes', 'Yes', 'Yes','Yes','Yes','Yes', 'Negative', 'Yes', 'None', 3, 3))

#con.execute('''INSERT INTO Procedure (Fixed, Flea, Dewormed, Microchip, EarCleaning, EarMite, NailTrim, FIVTest, FIVResult, EarTip, Notes, VetID, CatID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);''' ('Yes', 'Yes', 'Yes', 'Yes', 'Yes','Yes','Yes','Yes', 'Negative', 'Yes', 'None', 4, 4))

#con.execute('''INSERT INTO Procedure (Fixed, Flea, Dewormed, Microchip, EarCleaning, EarMite, NailTrim, FIVTest, FIVResult, EarTip, Notes, VetID, CatID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);''' ('Yes', 'Yes', 'Yes', 'Yes', 'Yes','Yes','Yes','Yes', 'Negative', 'Yes', 'None', 5, 5))

#con.execute('''INSERT INTO Procedure (Fixed, Flea, Dewormed, Microchip, EarCleaning, EarMite, NailTrim, FIVTest, FIVResult, EarTip, Notes, VetID, CatID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);''' ('Yes', 'Yes', 'Yes', 'Yes', 'Yes','Yes','Yes','Yes', 'Negative', 'Yes', 'None', 1, 1))

#Create Vaccine Table
con.execute('''
CREATE TABLE IF NOT EXISTS Vaccine(
    VisitID INTEGER Primary Key AUTOINCREMENT,
    ComboShot TEXT,
    Rabies TEXT,
    VetID INTEGER,
    CatID INTEGER,
    Foreign key (VetID) References Vet(VetID),
    Foreign key (CatID) References Cat(CatID)
);''')

#Insert Vaccine Records
#con.execute('''INSERT INTO Vaccine(ComboShot, Rabies, VetID, CatID) VALUES(?,?,?,?);''' ('Yes', 'Yes', 1, 1))

#con.execute('''INSERT INTO Vaccine(ComboShot, Rabies, VetID, CatID) VALUES(?,?,?,?);''' ('Yes', 'No', 2, 2))

#con.execute('''INSERT INTO Vaccine(ComboShot, Rabies, VetID, CatID) VALUES(?,?,?,?);''' ('No', 'Yes', 3, 3))

#con.execute('''INSERT INTO Vaccine(ComboShot, Rabies, VetID, CatID) VALUES(?,?,?,?);''' ('No', 'No', 4, 4))

#con.execute('''INSERT INTO Vaccine(ComboShot, Rabies, VetID, CatID) VALUES(?,?,?,?);''' ('Yes', 'Yes', 5, 5))

#Create Microchip Table
con.execute('''
CREATE TABLE IF NOT EXISTS Microchip(
    MicrochipNBR INTEGER PRIMARY KEY AUTOINCREMENT,
    Provider TEXT,
    Date DATE,
    CatID INTEGER,
    Foreign Key (CatID) references Cat(CatID)
);''')

#con.execute('''INSERT INTO Microchip(Provider, Date, CatID) VALUES(?,?,?);''' ('KarmaKat', '01-01-2024', 1))

#con.execute('''INSERT INTO Microchip(Provider, Date, CatID) VALUES(?,?,?);''' ('KarmaKat', '09-10-2024', 2))

#con.execute('''INSERT INTO Microchip(Provider, Date, CatID) VALUES(?,?,?);''' ('KarmaKat', '06-17-2023', 3))

#con.execute('''INSERT INTO Microchip(Provider, Date, CatID) VALUES(?,?,?);''' ('KarmaKat', '07-01-2021', 4))

#con.execute('''INSERT INTO Microchip(Provider, Date, CatID) VALUES(?,?,?);''' ('KarmaKat', '03-09-2022', 5))

#Create Combo Table
con.execute('''
CREATE TABLE IF NOT EXISTS Combo(
    Date1 DATE,
    Date2 DATE,
    Date3 DATE,
    CatID INTEGER,
    Foreign Key (CatID) References Cat(CatID)
);''')

#Input Combo Records
#con.execute('''INSERT INTO Combo(Date1, Date2, Date3, CatID) VALUES(?,?,?,?);''' ('2025-1-1', None,None,1))

#con.execute('''INSERT INTO Combo(Date1, Date2, Date3, CatID) VALUES(?,?,?,?);''' ('2025-1-1', '2024-6-1','2024-1-1',2))

#con.execute('''INSERT INTO Combo(Date1, Date2, Date3, CatID) VALUES(?,?,?,?);''' ('2025-1-1', '2023-9-8',None,3))

#con.execute('''INSERT INTO Combo(Date1, Date2, Date3, CatID) VALUES(?,?,?,?);''' (None, None,None,4))

#con.execute('''INSERT INTO Combo(Date1, Date2, Date3, CatID) VALUES(?,?,?,?);''' ('2023-6-5', '2022-6-8',None,5))

#Create Medical Information Table
con.execute ('''
CREATE TABLE IF NOT EXISTS MedicalInformation(
    MedID Integer Primary Key Autoincrement,
    CatID INTEGER,
    Procedure TEXT,
    Vaccination TEXT,
    Foreign Key (CatID) References Cat(CatID)
);''')

#con.execute('''INSERT INTO MedicalInformation (CatID, Procedure, Vaccination) VALUES  (?,?,?); ''', (1, 'Neutering', 'Rabies'))

#con.execute('''INSERT INTO MedicalInformation (CatID, Procedure, Vaccination) VALUES  (?,?,?); ''', (2, 'Neutering', 'Rabies'))

#con.execute('''INSERT INTO MedicalInformation (CatID, Procedure, Vaccination) VALUES  (?,?,?); ''', (3, 'Spay', 'None'))

#con.execute('''INSERT INTO MedicalInformation (CatID, Procedure, Vaccination) VALUES  (?,?,?); ''', (4, 'Neutering', 'None'))

#con.execute('''INSERT INTO MedicalInformation (CatID, Procedure, Vaccination) VALUES  (?,?,?); ''', (5, 'Spay', 'Rabies'))

#Create Staff Table
con.execute('''CREATE TABLE IF NOT EXISTS Staff(
    emp_id INTEGER PRIMARY KEY,
    position TEXT,
    volunteer_yn TEXT,
    Foreign Key (emp_id) References Person(person_id));''')

#Insert Staff
#con.execute('''INSERT INTO Staff(emp_id, position, volunteer_yn) Values(?, ?, ?)''', (1, 'Employee', 'N'))

#con.execute('''INSERT INTO Staff(emp_id, position, volunteer_yn) Values(?, ?, ?)''', (2, 'Employee', 'N'))

#con.execute('''INSERT INTO Staff(emp_id, position, volunteer_yn) Values(?, ?, ?)''', (3, 'Employee', 'N'))

#con.execute('''INSERT INTO Staff(emp_id, position, volunteer_yn) Values(?, ?, ?)''', (4, 'Employee', 'N'))

#con.execute('''INSERT INTO Staff(emp_id, position, volunteer_yn) Values(?, ?, ?)''', (5, 'Employee', 'N'))

#Create Person Table
con.execute('''CREATE TABLE IF NOT EXISTS Person(
    person_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT,
    last_name TEXT,
    street TEXT,
    city TEXT,
    state TEXT,
    zip_code INTEGER,
    phone TEXT,
    staff_yn TEXT,
    username TEXT);''')

#Input Persons
#con.execute('''INSERT INTO Person(person_id, first_name, last_name, street, city, state, zip_code, phone, staff_yn, username) VALUES(?,?,?,?,?,?,?,?,?,?)''', (1, "Tommy", "Minkus", "Honey", "Jackson", "MI", "49201", "Y", "tommyminkus"))

#con.execute('''INSERT INTO Person(person_id, first_name, last_name, street, city, state, zip_code, phone, staff_yn, username) VALUES(?,?,?,?,?,?,?,?,?,?)''', (2, "Kelly", "Bluebook", "Jamestown", "Detroit", "MI", "48402", "Y", "kellybluebook"))

#con.execute('''INSERT INTO Person(person_id, first_name, last_name, street, city, state, zip_code, phone, staff_yn, username) VALUES(?,?,?,?,?,?,?,?,?,?)''', (3, "Kyle", "Schroder", "Noodle Dr", "Lansing", "MI", "48509", "Y", "kyleschroder"))

#con.execute('''INSERT INTO Person(person_id, first_name, last_name, street, city, state, zip_code, phone, staff_yn, username) VALUES(?,?,?,?,?,?,?,?,?,?)''', (4, "Justin", "Case", "Jamestown", "Detroit", "MI", "48402", "Y", "justincase"))

#con.execute('''INSERT INTO Person(person_id, first_name, last_name, street, city, state, zip_code, phone, staff_yn, username) VALUES(?,?,?,?,?,?,?,?,?,?)''', (5, "Bella", "Longone", "Deerfield", "Mount Pleasant", "MI", "48858", "Y", "bellalongone"))

#make sure database writes data to disk
con.commit()

#close the connection
con.close()
